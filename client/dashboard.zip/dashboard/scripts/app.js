(function () {
    'use strict';

    angular.module('app.dashboard', [
    	'ngRoute',
    	'ngResource',
    	'ui.bootstrap'
    	]);

})();
