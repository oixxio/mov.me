(function () {
    'use strict';

    angular.module('app.dashboard').
    factory('apiFactory', ['$http', function($http){
    	var api = {};

        
    	
    	return api;
    }]);

})();